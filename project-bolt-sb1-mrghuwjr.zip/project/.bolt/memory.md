# Project memory

## Product intent & audience

- Sistema de gestão escolar focado em planos de aula, com pastas hierárquicas e fluxo de validação/publicação.
- Usuários internos da escola, com perfis: administrador, coordenador e docente.
- Objetivo: permitir que todos os perfis logados naveguem pela árvore completa de pastas e visualizem planos publicados, como em um explorador de arquivos (Windows Explorer).

## Brand personality & voice

- Tom direto e utilitário, voltado a operação escolar diária.
- Comunicação em Português (Brasil).
- Mensagens de erro devem expor a causa real (ex.: senha recusada pelo Supabase, falha ao salvar perfil/pasta).

## Visual design & UX direction

- Navegação de pastas em árvore, com trilha de caminho (breadcrumb) funcional em qualquer pasta e para qualquer perfil.
- Visualização estilo explorador de arquivos: pastas e planos listados de forma hierárquica.
- Ícones via lucide-react.
- Evitar restrições de UI por perfil na árvore: administrador, coordenador e docente veem a mesma estrutura de navegação.

## Decisions, constraints & rationale

- Stack: Vite + React (JSX), Tailwind, hooks, lucide-react; `@/` aponta para `src/`.
- Backend/auth: Supabase; mínimo global de senha é 6 caracteres (não controlável pelo app).
- App aceita senha simples a partir de 4 caracteres; quando o Supabase rejeita (<6), o erro é exibido claramente ao usuário.
- Acesso por perfil:
  - Árvore de pastas: leitura para todos os usuários logados.
  - Planos publicados: visualização por qualquer usuário logado, em qualquer pasta.
  - Planos em validação: restritos à equipe responsável conforme o perfil.
  - Arquivos publicados: abertos por usuários autorizados.
- Falhas de cadastro podem ocorrer ao salvar vínculo de perfil/pasta, não apenas na senha; tratar explicitamente.

## Open questions & assumptions

- Assume-se que o mínimo de 6 caracteres do Supabase não será alterado; se precisar de senhas mais curtas, exigir ajuste global no Supabase.
- Não está claro se coordenador deve editar/mover planos em validação ou apenas visualizar.
- Pendente confirmar se docente pode criar planos em qualquer pasta ou apenas nas vinculadas ao seu perfil.
- Não definido se há limite de profundidade de pastas ou se pastas vazias devem ser ocultadas/exibidas.